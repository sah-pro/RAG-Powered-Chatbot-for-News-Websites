
import { useState } from 'react';
import axios from 'axios';

function App() {
    const [sessionId] = useState('session-1');
    const [question, setQuestion] = useState('');
    const [messages, setMessages] = useState([]);

    const askQuestion = async () => {
        const res = await axios.post('http://localhost:5000/query', { sessionId, question });
        setMessages([...messages, { question, answer: res.data.answer }]);
        setQuestion('');
    };

    return (
        <div>
            <h1>News Chatbot</h1>
            {messages.map((m, i) => (
                <div key={i}>
                    <b>You:</b> {m.question}<br />
                    <b>Bot:</b> {m.answer}
                </div>
            ))}
            <input value={question} onChange={e => setQuestion(e.target.value)} />
            <button onClick={askQuestion}>Ask</button>
        </div>
    );
}

export default App;
