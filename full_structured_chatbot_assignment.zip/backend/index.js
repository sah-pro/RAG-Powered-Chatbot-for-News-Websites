
require('dotenv').config();
const express = require('express');
const axios = require('axios');
const redis = require('redis');
const { v4: uuidv4 } = require('uuid');

const app = express();
app.use(express.json());

const port = process.env.PORT || 3000;
const redisClient = redis.createClient({ url: process.env.REDIS_URL });
redisClient.connect().catch(console.error);

app.post('/query', async (req, res) => {
    const { sessionId, question } = req.body;

    // Mocked Qdrant search
    const relevantText = "Sample news passage related to the query.";

    // Mocked Gemini API call
    const answer = "This is a sample mocked answer.";

    await redisClient.rPush(sessionId, `Q: ${question}\nA: ${answer}`);
    res.json({ answer });
});

app.get('/history/:sessionId', async (req, res) => {
    const replies = await redisClient.lRange(req.params.sessionId, 0, -1);
    res.json({ history: replies });
});

app.post('/reset-session', async (req, res) => {
    const { sessionId } = req.body;
    await redisClient.del(sessionId);
    res.json({ message: 'Session reset' });
});

app.listen(port, () => console.log(`Backend running at http://localhost:${port}`));
