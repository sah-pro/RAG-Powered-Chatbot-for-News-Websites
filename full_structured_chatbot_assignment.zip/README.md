
# Full Structured RAG News Chatbot

## Tech Stack Used:
- Node.js + Express
- React + SCSS
- Redis (with dotenv config)
- Jina Embeddings (Mocked)
- Qdrant (Mocked)
- Google Gemini API (Mocked)

## How to Run Locally:
1. Start Redis: `docker run -p 6379:6379 redis`
2. Start Backend:
   - Install dependencies: `npm install express axios redis uuid dotenv`
   - Run: `node index.js` (in backend folder)
3. Start Frontend:
   - Install dependencies: `npm install axios`
   - Run: `npm start` (in frontend folder)

## Notes:
- Mocked Gemini and Qdrant API calls for demonstration.
- Replace mock code with real API calls when ready.
